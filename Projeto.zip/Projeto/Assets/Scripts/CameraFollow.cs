﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class CameraFollow : MonoBehaviour {

	Transform tr;

	public Transform target;

	// Use this for initialization
	void Start () {

		tr = GetComponent<Transform> ();

		
	}
	
	// Update is called once per frame
	void Update () {

		tr.position = Vector2.Lerp (tr.position, target.position, 0.05f);
		
	}
}
