﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class GameStats : MonoBehaviour {

	public int score;

	public Text textoScore;

	// Use this for initialization
	void Start () {

		score = 0;
		
	}
	
	// Update is called once per frame
	void Update () {
		
		textoScore.text = score.ToString();
		
	}
}
