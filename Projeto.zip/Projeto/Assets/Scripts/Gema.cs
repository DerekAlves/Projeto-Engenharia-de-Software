﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Gema : MonoBehaviour {

	public Explosao explosao;

	GameStats gameStats;

	Transform tr;

	void Start(){

		tr = GetComponent<Transform> ();
		gameStats = FindObjectOfType<GameStats> ();
	}

	void OnTriggerEnter2D(Collider2D other){

		if (other.tag == "Player") {
			Destroy (gameObject);
			Instantiate (explosao, tr.position, tr.rotation);
			gameStats.score++;

		}

	}

}
