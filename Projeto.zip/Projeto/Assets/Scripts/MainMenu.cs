﻿using System.Collections;
using UnityEngine;
using UnityEngine.SceneManagement;

public class MainMenu : MonoBehaviour {

	public string cena;


	// Use this for initialization
	void Start () {
		
	}
	
	// Update is called once per frame
	void Update () {
		
	}

	public void CarregarCena (){

		SceneManager.LoadScene (cena);
	}

	public void QuitGame(){
	
		Application.Quit ();
	}

}
