﻿ using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class MoverRaposa : MonoBehaviour 
{
	Transform tr;
	Rigidbody2D rb;
	SpriteRenderer sr;
	Animator anim;

	public float velocidade;
	public float forcaPulo;
	public bool noChao;

	float moveX;
	bool pulo;



	void Start () {

		tr = GetComponent<Transform> ();
		rb = GetComponent<Rigidbody2D> ();
		sr = GetComponent<SpriteRenderer> ();
		anim = GetComponent<Animator> ();
	}


	void Update () {

		ChecarEstadoAnimacao ();

		if (Input.GetKey (KeyCode.RightArrow)) {

			moveX = 1;



		} else if (Input.GetKey (KeyCode.LeftArrow)) {

			moveX = -1;



		} else {

			moveX = 0;

		}

		tr.Translate (new Vector2 (moveX, 0) * velocidade * Time.deltaTime);

		if (Input.GetKeyDown (KeyCode.Space) && noChao) {

			pulo = true;
		}

	}

	void FixedUpdate(){

		noChao = Physics2D.Raycast (tr.position, Vector2.down, 1.1f, 1 << 8);

		if (pulo) {

			rb.AddForce (Vector2.up * forcaPulo, ForceMode2D.Impulse);
			pulo = false;
		}

	}

	void ChecarEstadoAnimacao(){

		if (moveX > 0f && noChao) {

			anim.SetInteger ("EstadoAnimacao", 1);
			sr.flipX = false;

		} else if (moveX < 0f && noChao) {

			anim.SetInteger ("EstadoAnimacao", 1);
			sr.flipX = true;

		} else if (moveX == 0f && noChao) {

			anim.SetInteger ("EstadoAnimacao", 0);

		} else if (!noChao) {

			anim.SetInteger ("EstadoAnimacao", 2);

		}


	}
}
